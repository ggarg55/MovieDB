//
//  ImageCache.swift
//  MovieDb
//
//  Created by Gourav Garg on 30/11/20.
//

import Foundation
import UIKit
private let _imageCache = NSCache<AnyObject, AnyObject>()

class ImageCache: NSObject {

    var imageCache = _imageCache
//    var imageObs = DataObservable<UIImage?>(nil)
//    var shared = ImageCache()
//    private override init() {
//        super.init()
//    }
    func fetchImage(url: URL, completion: @escaping(UIImage?) -> Void) {
        let urlString = url.absoluteString
        if let imageFromCache = imageCache.object(forKey: urlString as AnyObject) as? UIImage {
            //self.imageObs.value = imageFromCache
            DispatchQueue.main.async { [weak self] in
                completion(imageFromCache)
            }
            return
        }
        
        DispatchQueue.global(qos: .background).async { [weak self] in
            guard let self = self else { return }
            do {
                let data = try Data(contentsOf: url)
                guard let image = UIImage(data: data) else {
                    return
                }
                self.imageCache.setObject(image, forKey: urlString as AnyObject)
                DispatchQueue.main.async {
                    completion(image)
                    //self?.imageObs.value = image
                }
            } catch {
                print(error.localizedDescription)
            }
        }

    }

}
