//
//  JsonParsingError.swift
//  MovieDb
//
//  Created by Gourav Garg on 29/11/20.
//

import Foundation

enum JsonParsingError: Error {
    case badURL
    case unknownError(Error)
}
