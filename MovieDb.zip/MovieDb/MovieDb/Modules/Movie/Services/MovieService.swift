//
//  MovieService.swift
//  MovieDb
//
//  Created by Gourav Garg on 29/11/20.
//

import Foundation

protocol MovieServiceProtocol {
    func fetchMoviesFromServer(completion: @escaping (PlayingNowResponse?, NetworkError?) -> Void)
    func restoreStoredMovies(completion: @escaping (PlayingNowResponse?, NetworkError?) -> Void)
    func storeMoviesToDB(response: PlayingNowResponse)
}

class MovieService: MovieServiceProtocol {
    
    func fetchMoviesFromServer(completion: @escaping (PlayingNowResponse?, NetworkError?) -> Void) {
        let query = [kApiKey: MovieApiConstants.key.rawValue]
        let request = ApiRequest<PlayingNowResponse>(host: MovieApiConstants.baseURL.rawValue, path: MovieApiEndPoints.nowPlaying.rawValue,queryParameters: query)
        request.execute(completion: {[weak self](response,error)in
            guard let self = self else { return }
            if let response = response {
                print(response)
                self.storeMoviesToDB(response: response)
            } else {
                print(error ?? "")
                self.restoreStoredMovies(completion: completion)
            }
            completion(response,error)
        })
    }
    
    func storeMoviesToDB(response: PlayingNowResponse) {
        // Store movies to db
    }
    
    // GET Movies List from the Database
    func restoreStoredMovies(completion: @escaping (PlayingNowResponse?, NetworkError?) -> Void) {
        
    }
}
