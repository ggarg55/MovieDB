//
//  ViewController.swift
//  MovieDb
//
//  Created by Gourav Garg on 29/11/20.
//

import UIKit

class ViewCell: UITableViewCell {
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var favButton: UIButton!
    @IBOutlet weak var posterImageView: UIImageView!
}

class ViewController: UIViewController {
    let viewModel = MovieViewModel()
    var data: [MovieResults] = []
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //getFavouriteMovies()
        bindViewModel()
    }
}

/// MARK: - ViewModel Bindings
extension ViewController {
    func bindViewModel() {
        viewModel.getMovieData()
        viewModel.movieList.bind {[weak self] resp in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.data = resp
                self.refreshView()
            }
        }
    }
    
    func refreshView() {
        tableView.reloadData()
    }
    
    func addFavourite(movie: MovieResults) {
        viewModel.addFavouriteMovie(movie: movie)
    }
    
    func getFavouriteMovies() {
        viewModel.getFavouriteMovies()
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! ViewCell
        let cache = ImageCache()
        cache.fetchImage(url: data[indexPath.row].posterURL) {
            if let img = $0 {
                cell.posterImageView.image = img
            }
        }
        cell.titleLabel.text = data[indexPath.row].title
        cell.favButton.isHidden = data[indexPath.row].isFaviourate
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return self.view.frame.size.height //-yourTableViewStartingYPosition
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var movie = data[indexPath.row]
        movie.isFaviourate = true
        data = data.map({
            if $0.id == movie.id {
                var d = $0
                d.isFaviourate = true
                return d
            }
            return $0
        })
        viewModel.addFavouriteMovie(movie: movie)
        refreshView()
    }
}
