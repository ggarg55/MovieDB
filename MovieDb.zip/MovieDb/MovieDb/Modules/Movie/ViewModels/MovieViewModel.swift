//
//  MovieViewModel.swift
//  MovieDb
//
//  Created by Gourav Garg on 30/11/20.
//

import Foundation
import CoreData

class MovieViewModel {
    
    typealias completion = (PlayingNowResponse?, NetworkError?) -> Void
    var movieData: PlayingNowResponse?
    var movieList = DataObservable<[MovieResults]>([])
    let kMovieEntity = "MovieData"
    lazy var service = MovieService()
    
    func getMovieData() {
        if !Reachability.isConnectedToNetwork() {
            self.getFavouriteMovies()
            return
        }
        service.fetchMoviesFromServer { [weak self] (res, err) in
            guard let self = self else { return }
            if let response = res {
                self.movieData = response
                self.movieList.value = response.results ?? []
            } else {
                self.movieData = nil
                self.movieList.value = []
            }
        }
    }
    
    func addFavouriteMovie(movie: MovieResults) {
        var favMovie = movie
        favMovie.isFaviourate = true
        // Add to db
        let managedObjectContext = AppDelegate.delegate!.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: kMovieEntity, in: managedObjectContext)!
        let data = NSManagedObject(entity: entity, insertInto: managedObjectContext)
        data.setValue(favMovie.id, forKey: "id")
        guard let obj = try? JSONEncoder().encode(favMovie) else {
            return
        }
        data.setValue(obj, forKey: "data")
        try? managedObjectContext.save()
    }
    
    func getFavouriteMovies() {
        // get from db
        let managedObjectContext = AppDelegate.delegate!.persistentContainer.viewContext
        let request = NSFetchRequest<NSManagedObject>(entityName: kMovieEntity)
        do {
            let movies = try managedObjectContext.fetch(request)
            var list: [MovieResults] = []
            movies.forEach { (ob) in
                if let mve = try? JSONDecoder().decode(MovieResults.self, from: ob.value(forKey: "data") as! Data) {
                    list.append(mve)
                }
            }
            movieList.value = list
        } catch {
            debugPrint(error.localizedDescription)
        }
        
    }
    
}
