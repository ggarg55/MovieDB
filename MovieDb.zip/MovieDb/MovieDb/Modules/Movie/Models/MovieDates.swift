//
//  MovieDates.swift
//  MovieDb
//
//  Created by Gourav Garg on 29/11/20.
//

import Foundation

// MARK: - MovieDates
struct MovieDates : Codable {
    let minimum : String?
    let maximum : String?

    enum CodingKeys: String, CodingKey {

        case minimum = "minimum"
        case maximum = "maximum"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        minimum = try values.decodeIfPresent(String.self, forKey: .minimum)
        maximum = try values.decodeIfPresent(String.self, forKey: .maximum)
    }

}

