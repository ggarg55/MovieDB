//
//  PlayingNowResponse.swift
//  MovieDb
//
//  Created by Gourav Garg on 29/11/20.
//

import Foundation

struct PlayingNowResponse : Codable {
    let total_pages : Int?
    let results : [MovieResults]?
    let page : Int?
    let dates : MovieDates?
    let total_results : Int?

    enum CodingKeys: String, CodingKey {

        case total_pages = "total_pages"
        case results = "results"
        case page = "page"
        case dates = "dates"
        case total_results = "total_results"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        total_pages = try values.decodeIfPresent(Int.self, forKey: .total_pages)
        results = try values.decodeIfPresent([MovieResults].self, forKey: .results)
        page = try values.decodeIfPresent(Int.self, forKey: .page)
        dates = try values.decodeIfPresent(MovieDates.self, forKey: .dates)
        total_results = try values.decodeIfPresent(Int.self, forKey: .total_results)
    }
}
