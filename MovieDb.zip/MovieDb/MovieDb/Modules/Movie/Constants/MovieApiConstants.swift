//
//  MovieApiConstants.swift
//  MovieDb
//
//  Created by Gourav Garg on 29/11/20.
//

import Foundation
let kApiKey = "api_key"

enum MovieApiConstants: String {
    case baseURL = "https://api.themoviedb.org/3"
    case key = "34c902e6393dc8d970be5340928602a7"
}

enum MovieApiEndPoints: String, CaseIterable {
    case nowPlaying = "/movie/now_playing"
}
